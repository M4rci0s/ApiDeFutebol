import AppRoutes from "../src/routes";

function App() {
  return <AppRoutes />;
}

export default App;
